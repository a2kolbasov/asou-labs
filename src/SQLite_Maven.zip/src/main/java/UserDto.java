
//@Getter // lombock
//@Setter
public class UserDto {
	public int id;
	public String name;
	public String login;
	public String password;
	
	/*
	private String password;
	
	public void setPassword(String value) {
		password = value;
	}
	
	public String getPassword() {
		return password;
	}
	*/
}

public class DbCntext {
	
	private static Logger log = Logger.getLogger(DbCntext.class.getName());
	private final String _connectionString;
	
	public DbCntext(String connectionString)
	{
		_connectionString = connectionString;
	}
	
	public Connection getConnection() {
		try
		{
			DriverManager.registerDriver(new JDBC());
			log.info("Connecting to db " + _connectionString);
			
			return DriverManager.getConnection(_connectionString);
		}
		catch (Exception e)
		{
			log.severe(e);
		}
	}
}
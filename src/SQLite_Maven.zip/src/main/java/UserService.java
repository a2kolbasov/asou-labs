
//@Component{ 
//	implement = true,
//	impl = IUserService.class
//}
public class UserService {
	
	private static Logger log = Logger.getLogger(UserService.class.getName());
	
	//@Reference // OSGI
	private DbCntext _dbContext;
	
	public UserService(DbCntext dbContext) {
		_dbContext = dbContext;
	}
	
	private String getPasswordHash(String password) {
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		
		md5.update(password.getBytes());
		byte[] hashBytes = md5.digest();
		
		return DatatypeConvertor.printHexBinary(hashBytes);
	}
	
	public void AddUser(UserDto user) {
		PreparedStatment stmt = _dbContext.getConnection().prepareStatment(
				"insert into users (id,login,name,pass) values (?, ?, ?, ?)"
		);
			
		String passHash = getPasswordHash(user.password);
		
		stmt.setInt(1, user.id);
		stmt.setString(2, user.login);
		stmt.setString(3, user.name);
		stmt.setString(4, passHash);
		stmt.executeUpdate();
	}
	
	public List<UserDto> GetUsers() {
		Statment stmt = _dbContext.getConnection().createStatment();
		ResultSet usersResultSet = stmt.executeQuery("select id,name,login from users");
		List<UserDto> result = new ArrayList<>();
		
		while(usersResultSet.next())
		{
			UserDto user = new UserDto();
			user.id = usersResultSet.getInt("id");
			user.name = usersResultSet.getString("name");
			user.login = usersResultSet.getString("login");
			
			result.put(user);
		}
		
		return result;
	}
	
	public boolean IfEsist(String userLogin) {
		PreparedStatment stmt = _dbContext.getConnection().prepareStatment(
				"select 1 from users where login = ?"
		);
		
		stmt.setString(1, userLogin);
		ResultSet resultSet = stmt.executeQuery();
		
		return resultSet.next();
	}
}
import org.sqlite.JDBC;

public class Main {
	
	//private static Logger log = Logger.getLogger("main");
	private static Logger log = Logger.getLogger(Main.class.getName());
	
	public static void main(String[] args) {
		try {			
			String con_string = "jdbc:sqlite:./my.db";
			
			log.info("Starting");
			//log.log(Level.INFO, "Starting");
			
			DbCntext dbContext = new DbCntext(con_string);
			UserService userService = new UserService(dbContext);
			
			//ServiceProvider.addService<dbContext>();
			//ServiceProvider.addService<IUserService, UserService>();
			
			//UserService userService = ServiceProvider.getService<UserService>();
			
			if(!userService.IsEsist("admin@mail.ru"))
			{
				UserDto user = new UserDto();
				user.id = 1;
				user.login = "admin@mail.ru";
				user.name = "�����";
				user.password = "123";
				
				userService.AddUser(user);
			}
			
			log.info("Users:");
			for(UserDto user : userService.GetUsers())
			{
				log.info(user.id + "\t" + user.login + "\t" + user.name);
			}
		}
		catch (Exception e)
		{
			log.severe(e);
		}
	}
}